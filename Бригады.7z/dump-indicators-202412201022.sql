-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: 10.123.20.78    Database: indicators
-- ------------------------------------------------------
-- Server version	5.5.5-10.5.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `overtimes`
--

DROP TABLE IF EXISTS `overtimes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `overtimes` (
  `timesheet_id` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pass_` float NOT NULL,
  `gruz` float NOT NULL,
  `manevr` float NOT NULL,
  `household` float NOT NULL,
  `heaters` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `timesheet_id` (`timesheet_id`),
  CONSTRAINT `overtimes_ibfk_1` FOREIGN KEY (`timesheet_id`) REFERENCES `timesheets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `overtimes`
--

LOCK TABLES `overtimes` WRITE;
/*!40000 ALTER TABLE `overtimes` DISABLE KEYS */;
INSERT INTO `overtimes` VALUES (1,1,103.6,1193.7,184.7,242.4,130.7),(2,2,121.49,856.69,145.25,198.23,151.76),(3,3,40,270.7,129.6,197.5,134.5),(4,4,61.63,687.8,344.12,282.24,160.52),(5,5,143.7,1220.6,377.5,320.6,271),(6,6,84.06,442.62,125.29,191.75,128.71),(7,7,141,1090,174,284,102),(8,8,65.73,1489.3,166.52,238.7,205.03),(9,9,179,1734,161,231,155),(10,10,67.62,761.4,165.8,133.5,169.6),(11,11,146.3,143.9,249.8,361.9,161.8),(12,12,22.42,472.38,130.67,132.75,127.3),(13,13,159,1659,173.3,257,173.9),(14,14,112.7,2163,168.7,335.3,133.4),(15,15,101.1,1911.3,323.9,526.9,236.4),(16,16,92.36,1935.33,210.23,446.54,120.79),(17,17,51.9,1485.1,109.6,259,230),(18,18,3,73.92,14.8,30.16,3),(19,19,74.5,1512.7,208,303.9,145.4),(20,20,133.44,2430.15,137.53,278.19,90.94),(21,21,207,567.4,156.8,243.6,143.9),(22,22,211.3,1462.3,145,320,115.9);
/*!40000 ALTER TABLE `overtimes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `roles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Root',1),(4,'Alexey',4),(7,'Supplier',7),(8,'Admin',8);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `timesheets`
--

DROP TABLE IF EXISTS `timesheets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `timesheets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `month` int(11) NOT NULL,
  `year` int(11) NOT NULL,
  `norm` int(11) NOT NULL,
  `human_hours` int(11) NOT NULL,
  `pass_follow` int(11) NOT NULL,
  `rez_follow` int(11) NOT NULL,
  `wait_follow` int(11) NOT NULL,
  `vacations` int(11) NOT NULL,
  `diseases` int(11) NOT NULL,
  `distractions` int(11) NOT NULL,
  `business_trips` int(11) NOT NULL,
  `outside_depots` int(11) NOT NULL,
  `doublers` int(11) NOT NULL,
  `training_vacations` int(11) NOT NULL,
  `total_hours` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timesheets`
--

LOCK TABLES `timesheets` WRITE;
/*!40000 ALTER TABLE `timesheets` DISABLE KEYS */;
INSERT INTO `timesheets` VALUES (1,1,2023,136,569,7508,12187,2702,46,51,5,0,54,0,0,15212),(2,1,2024,136,701,7508,12187,2702,11,23,2,0,5,7,0,24039),(3,2,2023,143,425,5318,9077,1995,0,87,8,0,27,0,0,27166),(4,2,2024,159,278,5318,9077,1995,0,37,0,6,6,16,24,20989),(5,3,2023,175,138,6418,12620,2075,0,14,7,0,25,18,89,16314),(6,3,2024,159,340,9221,11146,2962,0,29,0,78,5,39,0,24985),(7,4,2023,160,278,7807,11983,2362,0,9,11,8,71,4,41,28226),(8,4,2024,168,322,10029,11639,3791,0,21,1,31,61,55,0,23553),(9,5,2023,160,316,7910,12298,2376,0,1,1,6,5,8,21,15544),(10,5,2024,159,495,9476,10785,4081,0,27,2,6,74,50,0,31317),(11,6,2023,168,201,6427,11114,1759,0,0,6,46,0,13,10,15803),(12,6,2024,151,529,10639,9697,4014,0,40,0,14,109,6,20,36661),(13,7,2023,168,241,7614,12741,2165,35,22,6,31,15,6,32,16505),(14,7,2024,184,241,8558,10796,2721,1,38,6,17,79,5,4,11306),(15,8,2023,184,140,7920,10737,2379,0,31,11,3,7,13,0,15741),(16,8,2024,176,234,8449,9187,2488,0,11,9,25,73,14,0,14443),(17,9,2023,168,240,10129,9894,3110,0,16,2,68,0,7,0,21297),(18,9,2024,168,279,7930,8980,2766,0,31,3,19,64,15,11,14628),(19,10,2023,176,323,9847,9857,3276,0,1,5,14,0,13,13,17090),(20,10,2024,215,184,9000,10127,2961,0,24,0,26,45,7,29,9302),(21,11,2024,159,263,6861,10448,1868,0,53,3,9,0,0,28,38209),(22,11,2023,176,199,6354,10475,1676,0,18,1,36,0,6,5,19300);
/*!40000 ALTER TABLE `timesheets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Root','Psd','djaks@mail.com'),(4,'Alexey','paswwd','mail@root.com'),(7,'User3','Passwd','maol@mail.ru'),(8,'Алексей','Passwd','xusiwi@mailinator.com');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'indicators'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-20 10:22:29
